from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import torch
import numpy as np
import torchvision.models as models
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import shap


from datareader import datareader
from utils import visualize, nbr_visualize, conf_visualize
from abconf import attribution_nbrs, compute_conformance

from glob import glob

import json



data_name = 'imagenet50'

parser = argparse.ArgumentParser(description='Interpreting the decision of classifier')
parser.add_argument('--dataset', type=str, default='imagenet', metavar='d',
                    help='an string giving location of dataset. ')
parser.add_argument('--sample', type=int, default=5, metavar='N',
                    help='an integer for count of samples. ')
parser.add_argument('--numpy',  default=False, action='store_true', 
                    help='is data numpy or image? ')
args = parser.parse_args()


#print(args.numpy)

# get the ML model
model = models.resnet50(pretrained=True)

# get the data
transformImage = transforms.Compose([
    transforms.Resize([224, 224]),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])
transformNpy = transforms.Compose([
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])
if args.numpy:
    transform = transformNpy
else:
    transform = transformImage

reader = datareader(batch_size = 10, isNumpy = args.numpy)
reader.data("data/imagenet",transform, model=model)

images, labels, filenames = reader.getBatch()

#print(images.shape)


# For debug, print the labels
print(labels)
model = model.eval()
output = model(images)
labels = torch.argmax(output, dim=1)
print(labels)


# Get the explanation
background = images[:14]
explainer = shap.GradientExplainer(model, background)
test_images = images[0:9]
test_filenames = filenames[0:9]
shap_values,indexes = explainer.shap_values(test_images, ranked_outputs=1, nsamples=5)
top_shap_values = torch.from_numpy(shap_values[0])


# Get the class dictionary for imagenet
url = "https://s3.amazonaws.com/deep-learning-models/image-models/imagenet_class_index.json"
fname = shap.datasets.cache(url)
with open(fname) as f:
    class_dict = json.load(f)


# visualize
visualize(test_images, indexes, shap_values, class_dict)

 
confidences = []
labels = []
for image, shap_value, filename in zip(test_images, top_shap_values, test_filenames):
    nbr_images, image, top_shap, mask_prob  = attribution_nbrs(image, shap_value, k_percentage = 10, N = 50, unpacked=True)
    nbr_visualize(nbr_images[0:5], image, top_shap[0:5], mask_prob[0:5])
    #print(labels)
    conf, label = compute_conformance(image, nbr_images, model)
    confidences.append(conf)
    labels.append(label)
    print(filename, "label :", label, "conf: ", conf)
conf_visualize(test_images, filenames, labels, top_shap_values, confidences, class_dict)

