from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch
import numpy as np
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from torch.utils.data import Dataset

from glob import glob
import json

class ImageFolderWithPaths(datasets.ImageFolder):
    """ Extends torchvision.datasets.ImageFolder
    """

    # override the __getitem__ method. this is the method that dataloader calls
    def __getitem__(self, index):
        # this is what ImageFolder normally returns 
        original_tuple = super(ImageFolderWithPaths, self).__getitem__(index)
        # the image file path
        path = self.imgs[index][0]
        # make a new tuple that includes original and the path
        tuple_with_path = (original_tuple + (path,))
        return tuple_with_path



class NumpyDataset(Dataset):
    
    def __init__(self, foldername, transform, model):   # initial logic happens like transform
        self.filenames  = glob(foldername + "/*/*.npy")
        self.images = torch.stack([transform(torch.from_numpy(np.load(f))) for f in self.filenames])
        if model is None:
            # set all class ids to -1 for the images
            self.tgts = torch.zeros([len(self.images)]) - 1
        else:
            output = (model.eval())(self.images)
            self.tgts = torch.argmax(output, dim=1)

    def __getitem__(self, index):
        return self.images[index], self.tgts[index], self.filenames[index], 

    def __len__(self):  # return count of sample we have
        return len(self.filenames)


class datareader:
    
    def __init__(self, num_workers = 0, batch_size = 10, isNumpy = False):
        self.num_workers = num_workers
        self.batch_size = batch_size
        self.dataset = None
        self.loader = None
        self.numpy = isNumpy

    """

    dataset (Dataset) – dataset from which to load the data.
    batch_size (int, optional) – how many samples per batch to load (default: 1)
    shuffle (bool, optional) – set to True to have the data reshuffled at every epoch (default: False).
    num_workers (int, optional) – how many subprocesses to use for data loading. 0 means that the data will be loaded in the main process. (default: 0)

    PyTorch ImageFolder produces dataset
    A generic data loader where the images are arranged in this way: ::
        root/dog/xxx.png
        root/dog/xxy.png
        root/dog/xxz.png
        root/cat/123.png
        root/cat/nsdf3.png
        root/cat/asd932_.png

     Attributes of returned loader:
        classes (list): List of the class names.
        class_to_idx (dict): Dict with items (class_name, class_index).
        samples (list): List of (sample path, class_index) tuples
        targets (list): The class_index value for each image in the dataset
    """
    def data(self,foldername, transform, batch_size = None, num_workers = None, model = None ):

        if self.numpy:
            self.dataset = NumpyDataset(foldername, transform, model)
            '''
            filenames  = glob(foldername + "/*/*.npy")
            images = torch.stack([transform(torch.from_numpy(np.load(f))) for f in filenames])
            if model is None:
                # set all class ids to -1 for the images
                tgts = torch.zeros([len(images)]) - 1
            else:
                output = (model.eval())(images)
                tgts = torch.argmax(output, dim=1)
            self.dataset = torch.utils.data.TensorDataset(images,tgts)
            self.samples = list(zip(filenames, tgts.tolist()))
            print(self.samples)
            '''
            '''
            def numpy_loader(path):
                return transform(torch.from_numpy(np.load(path)))
            self.dataset = datasets.DatasetFolder(foldername,numpy_loader)
            '''
                
                
        else:
            self.dataset = ImageFolderWithPaths(foldername, transform)
            #self.samples = self.dataset.samples
            #assert self.dataset is not None, "Please set dataset before calling get_loader")
            
        if batch_size is None:
            batch_size = self.batch_size
        if num_workers is None:
            num_workers   = self.num_workers
        self.loader = torch.utils.data.DataLoader(
            self.dataset,
            batch_size = batch_size, shuffle=False,
            num_workers = num_workers, pin_memory=True)
        
        
        
    
    def getBatch(self):
        assert self.loader is not None, "Please set loader before calling get_batch"
        # this would enumerate over val_loader one batch at a time
        #for i, (input, target) in enumerate(val_loader):
        batch = next(iter(self.loader))
        images, labels, filenames = batch
        #print(filenames, labels)
        return images, labels, filenames

        
            

