{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf500
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 # Attribution-based Confidence for Trust, Resilience and Interpretability in AI (Trinity-ABC)\
\
This tool uses a novel approach based on constructing attribution neighborhood and sampling in this neighborhood to measure conformance as a quantitative **confidence** of individual predictions made by a machine learning model.  The approach is based on the following paper:\
\
[Susmit Jha et. al. Attribution-Based Confidence Metric For Deep Neural Networks, Thirty-third Conference on Neural Information Processing Systems (NeurIPS) 2019.](https://papers.nips.cc/paper/9355-attribution-based-confidence-metric-for-deep-neural-networks)\
\
\
# Install\
\
Untar trinityALES.tar using\
```\
$ tar -xvf trinityALES.tar\
$ cd trinityALES\
``` \
\
It will create a new folder trinityALES with the tool in it along with test data. The only requirement before following the instruction below is to have Python 3 and pip installed on the system. For installing the tool, one can use pip or conda. The conda environment is recommended as it does not modify the system and can be deactivated and removed. \
\
## Using pip and requirements.txt\
\
In the trinityALES folder, there is a requirements.txt file which can be used to automatically install the prerequisite libraries for the ABC tool using the following command:\
```\
pip install -r requirements.txt\
```\
\
\
## Using conda and yaml file.\
\
In the trinityALES folder, an yaml file is included that contains the conda environment with required libraries for the ABC tool. The following command will create the conda environment with these packages, and then activate the environment.\
```\
$conda env create -f alesSRI.yaml\
$conda activate alesSRI\
```\
\
# Running the tool\
\
The ABC tool ships with a small number of data samples for testing. The instructions below will make use of these.\
\
The **runABC.py** script is the main run script that shows how to use the ABC tool. This script currently uses the following:\
\
- Resnet50 pretrained classification model as example ML model\
- Examples from Imagenet and confusing examples on which the model produces wrong results (created through adversarial attacks)\
- The example set is divided into two groups: **png** files and **numpy** files. The tool can accept either format. The **numpy** files are useful to consume artificially created confusing examples where the perturbations are too small and will be lost when saving as uint8 or uint32 png files.\
\
\
## Test running with provided models and samples\
\
We can run the tool with included model and examples by running either of the following two commands:\
\
- Run on png files in the data folder\
```\
python runABC.py\
```\
- Run on numpy files in the data folder\
```\
python runABC.py --numpy \
```\
\
This will create two outputs. \
- It will show visualization of the predictions (on randomly selected subset of the samples) and the computed confidence.\
\
- It will produce the computed confidence on the terminal, for example: \
```\
(alesSRI) jha@genesis:~/projects/trinityALES$ python runABC.py --numpy\
data/imagenet/numpy/AdvImage_5_438_to_907.npy label : 907 conf:  0.0\
data/imagenet/numpy/AdvImage_0_519_to_571.npy label : 571 conf:  0.18\
data/imagenet/numpy/OrigImage_3_243.npy label : 243 conf:  1.0\
data/imagenet/numpy/OrigImage_2_802.npy label : 802 conf:  1.0\
data/imagenet/numpy/AdvImage_3_243_to_242.npy label : 242 conf:  0.0\
data/imagenet/numpy/AdvImage_1_993_to_995.npy label : 995 conf:  0.0\
```\
\
### Modifying parameters of ABC algorithms\
\
The following parameters in the runABC.py script can be modified. \
\
#### Neighborhood sample count\
\
The number of neighborhood samples considered must be high to reduce the variance in the computed confidence. The tool ships with a fairly low sample size for faster execution on even low-memory GPUs. \
\
The function below constructs neighborhood with N=50 samples. \
```\
attribution_nbrs(image, shap_value, k_percentage = 10, N = 50, unpacked=True)\
```\
\
To modify it to have N=500 samples, change it to\
```\
attribution_nbrs(image, shap_value, k_percentage = 10, N = 500, unpacked=True)\
```\
#### Top percentile attributions to be used in neighborhood construction\
\
The tool ships with the threshold of constructing attribution neighborhood by sampling in the top 10% of the high attribution pixels (features). \
```\
attribution_nbrs(image, shap_value, k_percentage = 10, N = 50, unpacked=True)\
```\
\
This might need to be changed for a different model and dataset depending on whether the attribution is very concentrated or diffused. Typically, well-trained models show feature concentration. For example, this can be changed to top 5% by:\
```\
attribution_nbrs(image, shap_value, k_percentage = 5, N = 50, unpacked=True)\
```\
\
#### Visualizations\
\
The tool supports various visualizations.\
\
- The visualization of just the attributions can be achieved via\
```\
 visualize(test_images, indexes, shap_values, class_dict)\
```\
- The visualization of the neighborhood can be achieved via\
```\
nbr_visualize(nbr_images, image, top_shap, mask_prob)\
```\
- The visualization of the computed confidence can be achieved via\
```\
conf_visualize(test_images, filenames, labels, top_shap_values, confidences, class_dict)\
```\
## Advanced run with new models and samples\
\
In the runABC.py, replace the following with a new model:\
```\
model = models.resnet50(pretrained=True)\
```\
For example,\
```\
model = models.resnet18(pretrained=True)\
```\
\
In order to try the tool on new dataset, change the location of the inputs below (from data/imagenet to a new location):\
```\
reader = datareader(batch_size = 10, isNumpy = args.numpy)\
reader.data("data/imagenet",transform, model=model)\
```\
\
}