from __future__ import division


#from . import colorconv

import numpy as np
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.pyplot as pl


colors = []
for l in np.linspace(1, 0, 100):
    colors.append((30./255, 136./255, 229./255,l))
for l in np.linspace(0, 1, 100):
    colors.append((255./255, 13./255, 87./255,l))
red_transparent_blue = LinearSegmentedColormap.from_list("red_transparent_blue", colors)

colors = []
for l in np.linspace(0, 1, 100):
    colors.append((30./255, 136./255, 229./255,l))
transparent_blue = LinearSegmentedColormap.from_list("transparent_blue", colors)

colors = []
for l in np.linspace(0, 1, 100):
    colors.append((255./255, 13./255, 87./255,l))
transparent_red = LinearSegmentedColormap.from_list("transparent_red", colors)

def image_plot(shap_values, pixel_values, labels=None, width=20, aspect=0.2, hspace=0.2):
    multi_output = True
    if type(shap_values) != list:
        multi_output = False
        shap_values = [shap_values]

    # make sure labels
    if labels is not None:
        assert labels.shape[0] == shap_values[0].shape[0], "Labels must have same row count as shap_values arrays!"
        if multi_output:
            assert labels.shape[1] == len(shap_values), "Labels must have a column for each output in shap_values!"
        else:
            assert len(labels.shape) == 1, "Labels must be a vector for single output shap_values."

    label_kwargs = {} 

    # plot our explanations
    x = pixel_values
    fig_size = np.array([3 * (len(shap_values) + 1), 2.5 * (x.shape[0] + 1)])
    if fig_size[0] > width:
        fig_size *= width / fig_size[0]
    fig, axes = pl.subplots(nrows=x.shape[0], ncols=len(shap_values) + 1, figsize=fig_size)
    if len(axes.shape) == 1:
        axes = axes.reshape(1,axes.size)
    for row in range(x.shape[0]):
        x_curr = x[row].copy()

        # make sure
        if len(x_curr.shape) == 3 and x_curr.shape[2] == 1:
            x_curr = x_curr.reshape(x_curr.shape[:2])
        if x_curr.max() > 1:
            x_curr /= 255.

        # get a grayscale version of the image
        if len(x_curr.shape) == 3 and x_curr.shape[2] == 3:
            x_curr_gray = (0.2989 * x_curr[:,:,0] + 0.5870 * x_curr[:,:,1] + 0.1140 * x_curr[:,:,2]) # rgb to gray
        else:
            x_curr_gray = x_curr

        axes[row,0].imshow(x_curr, cmap=pl.get_cmap('gray'))
        axes[row,0].axis('off')
        if len(shap_values[0][row].shape) == 2:
            abs_vals = np.stack([np.abs(shap_values[i]) for i in range(len(shap_values))], 0).flatten()
        else:
            abs_vals = np.stack([np.abs(shap_values[i].sum(-1)) for i in range(len(shap_values))], 0).flatten()
        max_val = np.nanpercentile(abs_vals, 99.9)
        for i in range(len(shap_values)):
            if labels is not None:
                axes[row,i+1].set_title(labels[row,i], **label_kwargs)
            sv = shap_values[i][row] if len(shap_values[i][row].shape) == 2 else shap_values[i][row].sum(-1)
            axes[row,i+1].imshow(x_curr_gray, cmap=pl.get_cmap('gray'), alpha=0.15, extent=(-1, sv.shape[1], sv.shape[0], -1))
            im = axes[row,i+1].imshow(sv, cmap=red_transparent_blue, vmin=-max_val, vmax=max_val)
            axes[row,i+1].axis('off')
    if hspace == 'auto':
        fig.tight_layout()
    else:
        fig.subplots_adjust(hspace=hspace)
    cb = fig.colorbar(im, ax=np.ravel(axes).tolist(), label="Attribution", orientation="horizontal", aspect=fig_size[0]/aspect)
    cb.outline.set_visible(False)
    return pl

def visualize(images, indexes, shap_values, class_dict):
    # can't use moveaxis - there is a 0 axis keeping the list of all ip in batch
    shap_numpy = [np.swapaxes(np.swapaxes(s, 1, -1), 1, 2) for s in shap_values]
    test_numpy = np.swapaxes(np.swapaxes(images.numpy(), 1, -1), 1, 2)

    index_names = np.vectorize(lambda x: class_dict[str(x)][1])(indexes)
    
    # plot the feature attributions
    pl = image_plot(shap_numpy, test_numpy*255, index_names)
    pl.show()


def conf_visualize(images, filenames, indexes, top_shap_values, confidences, class_dict):
    fig = pl.figure()
    #print(len(images))
    index_names = np.vectorize(lambda x: class_dict[str(x)][1])(indexes)
    # plot the feature attributions
    for row, (image, top_shap, filename, index_name, conf) in enumerate(zip(images, top_shap_values, filenames, index_names, confidences)):
        ax = fig.add_subplot(len(images), 2, row * 2 + 1)
        ax.imshow(np.moveaxis(image.numpy(),0,2))
        ax.set_title(filename.split('/')[-1])
        pl.axis("off")
        ax = fig.add_subplot(len(images), 2, row * 2 + 2)

        #mask = top_shap > 0
        
        mask = top_shap.gt(0)
        top_shap = top_shap * mask
        top_shap = (top_shap - top_shap.min()) / (top_shap.max() - top_shap.min())
        ax.imshow(np.moveaxis(top_shap.numpy(),0,2))
        ax.set_title(index_name  + ":" + str(conf))
        pl.axis("off")
    pl.show()
    #pl.savefig("test.png")
    

def nbr_visualize(nbr_images, image, top_shap, mask_prob):
    #print(m[-1], torch.max(top_shap), torch.min(top_shap))
    fig = pl.figure()

    col = 4
    maxrow = len(nbr_images)
    for row, nbr in enumerate(nbr_images):
        ax1 = fig.add_subplot(maxrow, col, (row) * (col) + 1 )
        ax1.imshow(np.moveaxis(image.numpy(),0,2))
        ax1.axis('off')
        ax2 = fig.add_subplot(maxrow, col, (row) * (col) + 2 )
        ax2.imshow(np.moveaxis(top_shap.numpy()*255,0,2))
        ax2.axis('off')
        ax3 = fig.add_subplot(maxrow, col, (row) * (col) + 3 )
        ax3.imshow(np.moveaxis(mask_prob.numpy()*255,0,2))
        ax3.axis('off')
        ax4 = fig.add_subplot(maxrow, col, (row) * (col) + 4 )
        ax4.imshow(np.moveaxis(nbr.numpy(),0,2))
        ax4.axis('off')
        #ax4.set_title("hi")

    pl.show()
