from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


import torch
import numpy as np




def attribution_nbrs(image, top_shap, k_percentage=10, N=10, posThres=0.001, unpacked = False):
    # can use torch.numel if we want percentage to apply to all attr
    # and not just positive attr
    mask = top_shap.ge(posThres)
    pos_cnt = torch.sum(mask, dim=())
    kcnt = k_percentage/100.0 * pos_cnt
    #print("pos_cnt", pos_cnt, "kcnt", kcnt)
    flat_top_shap = torch.flatten(top_shap)
    kcnt = int(kcnt.item())
    m, _ = torch.topk(flat_top_shap,kcnt)
    if len(m) > 0:
        mask = top_shap.ge(m[-1])
    #else mask is just all ge posThres
    top_shap = top_shap * mask
    top_shap = (top_shap - top_shap.min()) / (top_shap.max() - top_shap.min())
    nbr_images = []
    for i in range(0, N):
        mask_prob = torch.bernoulli(top_shap)
        mask_prob = mask_prob.type(torch.bool)
        #top_shap = torch.masked_select(, mask)
        masked_image = image * ~mask_prob
        nbr_images.append(masked_image)
    if unpacked:
        return nbr_images, image, top_shap, mask_prob
    else:
        return nbr_images
    
    
def compute_conformance(image, nbr_images, model):
    nbr_images.append(image)
    nbr_output = model(torch.stack(nbr_images))
    labels = torch.argmax(nbr_output, dim=1)
    labels = (labels.detach().numpy()).tolist() 
    #print(labels, labels[-1])
    return float(labels.count(labels[-1])-1)/float(len(labels)-1), labels[-1]
